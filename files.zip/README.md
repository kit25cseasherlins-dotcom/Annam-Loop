# ReFeed - voice-first food rescue (Alexa+ MCP server)

Providers report leftover food. Safe time comes from a fixed rulebook (`safety.py`), never guessed by AI.
Unclaimed food past its safe time becomes waste and is offered only to biogas partners. Expired food never returns to consumers.

## Run
    pip install -r requirements.txt
    DEMO_SECONDS=60 python server.py      # MCP endpoint: http://localhost:8000/mcp (Streamable HTTP)
    python test_core.py                   # tests for the core logic

Optional Bedrock food-type fallback: `export BEDROCK_MODEL_ID=<model id>` and `AWS_REGION`.

## Tools
log_surplus, get_safe_window, find_nearby_surplus, claim_food, expire_listings,
get_waste_by_region, accept_waste_pickup, get_impact_stats

## Test with MCP Inspector
    npx @modelcontextprotocol/inspector     # connect to http://localhost:8000/mcp
